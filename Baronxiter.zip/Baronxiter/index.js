const {
    Client,
    GatewayIntentBits,
    Partials,
    REST,
    Routes,
    SlashCommandBuilder,
    ActivityType,
    PermissionsBitField,
} = require("discord.js");
const express = require("express");
const app = express();

app.get("/", (req, res) => res.send("Bot is alive!"));
app.listen(3000, () => console.log("🌐 Express server is running"));

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildVoiceStates,
    ],
    partials: [Partials.GuildMember],
});

const TOKEN =
    "MTM2MjM4MzU3MDI2NTcwMjYwMQ.GAvM0B.OQtf2xt4mxqppRoydPA5bz9_azfClLBEktwUSg";
const CLIENT_ID = "1362383570265702601";
const GUILD_ID = "1361108765558177912";

const commands = [
    new SlashCommandBuilder()
        .setName("avatar")
        .setDescription("Get the avatar of a user.")
        .addUserOption((option) =>
            option
                .setName("user")
                .setDescription("The user to get the avatar of")
                .setRequired(false),
        ),
    new SlashCommandBuilder()
        .setName("ban")
        .setDescription("Ban a user from the server")
        .addUserOption((option) =>
            option
                .setName("user")
                .setDescription("The user to ban")
                .setRequired(true),
        ),
    new SlashCommandBuilder()
        .setName("timeout")
        .setDescription("Timeout a user")
        .addUserOption((option) =>
            option
                .setName("user")
                .setDescription("The user to timeout")
                .setRequired(true),
        )
        .addIntegerOption((option) =>
            option
                .setName("seconds")
                .setDescription("Time in seconds")
                .setRequired(true),
        ),
    new SlashCommandBuilder()
        .setName("moveuser")
        .setDescription("Move a user to your voice channel")
        .addUserOption((option) =>
            option
                .setName("user")
                .setDescription("User to move")
                .setRequired(true),
        ),
    new SlashCommandBuilder()
        .setName("moveall")
        .setDescription("Move all users to your voice channel"),
    new SlashCommandBuilder()
        .setName("lock")
        .setDescription("Lock the current channel"),
    new SlashCommandBuilder()
        .setName("unlock")
        .setDescription("Unlock the current channel"),
    new SlashCommandBuilder()
        .setName("clear")
        .setDescription("Clear messages from the channel")
        .addIntegerOption((option) =>
            option
                .setName("amount")
                .setDescription("Number of messages to delete")
                .setRequired(true),
        ),
].map((cmd) => cmd.toJSON());

const rest = new REST({ version: "10" }).setToken(TOKEN);

client.once("ready", async () => {
    console.log(`✅ Logged in as ${client.user.tag}!`);
    try {
        await rest.put(Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID), {
            body: commands,
        });
        console.log("✅ Slash commands registered.");
    } catch (err) {
        console.error("❌ Failed to register slash commands:", err);
    }
    client.user.setActivity("By Baron Xiters </>", {
        type: ActivityType.Playing,
    });
});

client.on("guildMemberAdd", async (member) => {
    const role = member.guild.roles.cache.find(
        (role) => role.name === "𝐂𝐨𝐦𝐦𝐮𝐧𝐢𝐭𝐲",
    );
    const channel = member.guild.channels.cache.find(
        (ch) => ch.name === "👋・𝐖𝐞𝐥𝐜𝐨𝐦𝐞",
    );
    if (role) await member.roles.add(role).catch(console.error);
    if (channel)
        channel.send(
            `🎉 **Hi <@${member.id}> Welcome To Our Server Here You Will Find Best Free & Paid Panel Enjoy!**`,
        );
});

client.on("interactionCreate", async (interaction) => {
    if (!interaction.isChatInputCommand()) return;
    const { commandName } = interaction;

    if (commandName === "avatar") {
        const user = interaction.options.getUser("user") || interaction.user;
        return interaction.reply({
            content: `🖼️ Avatar of **${user.tag}**:
${user.displayAvatarURL({ dynamic: true, size: 1024 })}`,
        });
    }

    if (commandName === "ban") {
        const user = interaction.options.getUser("user");
        const member = await interaction.guild.members.fetch(user.id);
        if (!member.bannable)
            return interaction.reply({
                content: "❌ Cannot ban this user.",
                ephemeral: true,
            });
        await member.ban();
        return interaction.reply(`✅ Banned ${user.tag}`);
    }

    if (commandName === "timeout") {
        const user = interaction.options.getUser("user");
        const seconds = interaction.options.getInteger("seconds");
        const member = await interaction.guild.members.fetch(user.id);
        await member.timeout(seconds * 1000);
        return interaction.reply(
            `⏱️ Timed out ${user.tag} for ${seconds} seconds`,
        );
    }

    if (commandName === "moveuser") {
        const user = interaction.options.getUser("user");
        const member = await interaction.guild.members.fetch(user.id);
        const author = interaction.member;
        if (!author.voice.channel)
            return interaction.reply({
                content: "❌ You must be in a voice channel.",
                ephemeral: true,
            });
        if (!member.voice.channel)
            return interaction.reply({
                content: "❌ The user is not in a voice channel.",
                ephemeral: true,
            });
        await member.voice.setChannel(author.voice.channel);
        return interaction.reply(`✅ Moved ${user.tag} to your channel.`);
    }

    if (commandName === "moveall") {
        const author = interaction.member;
        if (!author.voice.channel)
            return interaction.reply({
                content: "❌ You must be in a voice channel.",
                ephemeral: true,
            });
        const members = interaction.guild.members.cache.filter(
            (m) => m.voice.channel && m.id !== author.id,
        );
        members.forEach((member) =>
            member.voice.setChannel(author.voice.channel),
        );
        return interaction.reply("✅ Moved all users to your channel.");
    }

    if (commandName === "lock") {
        const channel = interaction.channel;
        await channel.permissionOverwrites.edit(
            interaction.guild.roles.everyone,
            { SendMessages: false },
        );
        return interaction.reply("🔒 Channel locked.");
    }

    if (commandName === "unlock") {
        const channel = interaction.channel;
        await channel.permissionOverwrites.edit(
            interaction.guild.roles.everyone,
            { SendMessages: true },
        );
        return interaction.reply("🔓 Channel unlocked.");
    }

    if (commandName === "clear") {
        const amount = interaction.options.getInteger("amount");
        const messages = await interaction.channel.bulkDelete(amount, true);
        return interaction.reply({
            content: `🧹 Deleted ${messages.size} messages.`,
            ephemeral: true,
        });
    }
});

client.login(TOKEN);
